const gulp = require('gulp');
const colors = require('colors');
const moment = require('moment');
const rename = require('gulp-rename');
const apidoc = require('gulp-api-doc');
const awspublish = require("gulp-awspublish");
const parallelize = require("concurrent-transform");
const {s3Option} = require('./config');
const publisher = awspublish.create(s3Option);

colors.setTheme({
  info: 'green',
  error: 'red'
});

gulp.task('apidoc', () => {
    return gulp.src('api/*.js')
    .pipe(apidoc())
    .pipe(rename(function(path) { path.dirname = ['seo-api-docs', path.dirname].join('/') }))
    .pipe(parallelize(publisher.publish(), 10))
    .pipe(awspublish.reporter())
    .pipe(gulp.dest('output/docs')).on('end', function() {
        console.log('[' + moment().format('HH:mm:ss') + '] '+ colors.info('[success] ') + 'seo-web API文档更新完毕, 地址为 https://s3.cn-northwest-1.amazonaws.com.cn/mm-seo/test/seo-api-docs/index.html')
    });
});

//监听文件变化
gulp.task('watch', function() {
    gulp.watch('api/*.js', ['apidoc'])
});

gulp.task('default', ['apidoc']);
