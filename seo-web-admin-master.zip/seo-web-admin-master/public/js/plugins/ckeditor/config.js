/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	config.toolbar = [
		['Format','Font','FontSize','TextColor','BGColor','Bold','Italic','Underline','Strike','Subscript'],
		['NumberedList','BulletedList','Outdent','Indent','Blockquote'],
		['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
		['Link','Unlink','Anchor'],
		['Image','Table','HorizontalRule'],
		['Find','RemoveFormat','CopyFormatting','Source','Preview','Maximize','About']
	];

    //config.extraPlugins = 'simage';//注册插件

	config.plugins =
		'about,tableresize,autolink,' +
		'a11yhelp,' +
		'basicstyles,' +
		'bidi,' +
		'blockquote,' +
		'clipboard,' +
		'colorbutton,' +
		'colordialog,' +
		'copyformatting,' +
		'contextmenu,' +
		'dialogadvtab,' +
		'div,' +
		'elementspath,' +
		'enterkey,' +
		'entities,' +
		'filebrowser,' +
		'find,' +
		'flash,' +
		'floatingspace,' +
		'font,' +
		'format,' +
		'forms,' +
		'horizontalrule,' +
		'htmlwriter,' +
		'image2,' +
		'iframe,' +
		'indentlist,' +
		'indentblock,' +
		'justify,' +
		'language,' +
		'link,' +
		'list,' +
		'liststyle,' +
		'magicline,' +
		'maximize,' +
		'newpage,' +
		'pagebreak,' +
		'pastefromword,' +
		'pastetext,' +
		'preview,' +
		'print,' +
		'removeformat,' +
		'resize,' +
		'save,' +
		'selectall,' +
		'showblocks,' +
		'showborders,' +
		'smiley,' +
		'sourcearea,' +
		'specialchar,' +
		'stylescombo,' +
		'tab,' +
		'table,' +
		'tableselection,' +
		'tabletools,' +
		'templates,' +
		'toolbar,' +
		'undo,' +
		'uploadimage,' +
		'wysiwygarea';

	config.resize_maxHeight = 3000;
	//config.font_names='宋体/SimSun;新宋体/NSimSun;仿宋_GB2312/FangSong_GB2312;楷体_GB2312/KaiTi_GB2312;黑体/SimHei;微软雅黑/Microsoft YaHei;平方/PingFangSC-Regular;'+ config.font_names;

	config.font_names = '平方/PingFangSC-Regular;宋体/SimSun;新宋体/NSimSun;仿宋/FangSong;楷体/KaiTi;仿宋_GB2312/FangSong_GB2312;'+
        '楷体_GB2312/KaiTi_GB2312;黑体/SimHei;华文细黑/STXihei;华文楷体/STKaiti;华文宋体/STSong;华文中宋/STZhongsong;'+
        '华文仿宋/STFangsong;华文彩云/STCaiyun;华文琥珀/STHupo;华文隶书/STLiti;华文行楷/STXingkai;华文新魏/STXinwei;'+
        '方正舒体/FZShuTi;方正姚体/FZYaoti;细明体/MingLiU;新细明体/PMingLiU;微软雅黑/Microsoft YaHei;微软正黑/Microsoft JhengHei;'+
        'Arial Black/Arial Black;'+ config.font_names;

	// Remove some buttons provided by the standard plugins, which are
	// not needed in the Standard(s) toolbar.
	config.removeButtons = 'Subscript','Replace';

	// Set the most common block elements.
	config.format_tags = 'p;h1;h2;h3;pre';

	// Simplify the dialog windows.
	config.removeDialogTabs = 'image:advanced;link:advanced';


	//当从word里复制文字进来时，是否进行文字的格式化去除 plugins/pastefromword/plugin.js
    config.pasteFromWordIgnoreFontFace = true; //默认为忽略格式
    //是否使用<h1><h2>等标签修饰或者代替从word文档中粘贴过来的内容 plugins/pastefromword/plugin.js
    config.pasteFromWordKeepsStructure = false;
    //从word中粘贴内容时是否移除格式 plugins/pastefromword/plugin.js
    config.pasteFromWordRemoveStyle = false;

    //撤销的记录步数 plugins/undo/plugin.js
    config.undoStackSize = 100;

	// 取消 “拖拽以改变尺寸”功能 plugins/resize/plugin.js
    //config.resize_enabled = false;

	config.image_previewText = ' ';
	config.filebrowserImageUploadUrl= "/uploadImage.do?1=1";//上传图片的路径
	config.imageUploadURL= "/uploadImage.do?1=1";//上传图片的路径
	config.imagePasteHostWhitelist= ['https://ts.maimangup.com/seo/upload/images', 'https://ts.maimangup.com/seo/upload/images'];//不自动上传图片的白名单，此功能为将外链图片自动上传oss服务器并且替换

	//设置快捷键
    config.keystrokes = [
		[ CKEDITOR.CTRL + 90 /*Z*/, 'undo' ],  //撤销
        [ CKEDITOR.CTRL + 89 /*Y*/, 'redo' ],  //重做
        [ CKEDITOR.CTRL + CKEDITOR.SHIFT + 90 /*Z*/, 'redo' ],  //
        [ CKEDITOR.CTRL + 76 /*L*/, 'link' ],  //链接
        [ CKEDITOR.CTRL + CKEDITOR.SHIFT + 76 /*L*/, 'unlink' ],  //取消链接
        [ CKEDITOR.CTRL + 66 /*B*/, 'bold' ],  //粗体
        [ CKEDITOR.CTRL + 73 /*I*/, 'italic' ],  //斜体
        [ CKEDITOR.CTRL + 85 /*U*/, 'underline' ],  //下划线
        [ CKEDITOR.CTRL + 13 /*enter*/, 'maximize' ],
        [ CKEDITOR.CTRL + CKEDITOR.SHIFT + 80 /*P*/, 'image' ]//图片上传
    ]
};
