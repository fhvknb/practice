/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

// Compressed version of core/ckeditor_base.js. See original for instructions.
/* jshint ignore:start */
/* jscs:disable */
window.CKEDITOR||(window.CKEDITOR=function(){var e=/(^|.*[\\\/])ckeditor\.js(?:\?.*|;.*)?$/i,b={timestamp:"",version:"%VERSION%",revision:"%REV%",rnd:Math.floor(900*Math.random())+100,_:{pending:[],basePathSrcPattern:e},status:"unloaded",basePath:function(){var a=window.CKEDITOR_BASEPATH||"";if(!a)for(var b=document.getElementsByTagName("script"),c=0;c<b.length;c++){var f=b[c].src.match(e);if(f){a=f[1];break}}-1==a.indexOf(":/")&&"//"!=a.slice(0,2)&&(a=0===a.indexOf("/")?location.href.match(/^.*?:\/\/[^\/]*/)[0]+
a:location.href.match(/^[^\?]*\/(?:)/)[0]+a);if(!a)throw'The CKEditor installation path could not be automatically detected. Please set the global variable "CKEDITOR_BASEPATH" before creating editor instances.';return a}(),getUrl:function(a){-1==a.indexOf(":/")&&0!==a.indexOf("/")&&(a=this.basePath+a);this.timestamp&&"/"!=a.charAt(a.length-1)&&!/[&?]t=/.test(a)&&(a+=(0<=a.indexOf("?")?"&":"?")+"t="+this.timestamp);return a},domReady:function(){function a(){try{document.addEventListener?(document.removeEventListener("DOMContentLoaded",
a,!1),b()):document.attachEvent&&"complete"===document.readyState&&(document.detachEvent("onreadystatechange",a),b())}catch(f){}}function b(){for(var a;a=c.shift();)a()}var c=[];return function(b){c.push(b);"complete"===document.readyState&&setTimeout(a,1);if(1==c.length)if(document.addEventListener)document.addEventListener("DOMContentLoaded",a,!1),window.addEventListener("load",a,!1);else if(document.attachEvent){document.attachEvent("onreadystatechange",a);window.attachEvent("onload",a);b=!1;try{b=
!window.frameElement}catch(e){}if(document.documentElement.doScroll&&b){var d=function(){try{document.documentElement.doScroll("left")}catch(b){setTimeout(d,1);return}a()};d()}}}}()},d=window.CKEDITOR_GETURL;if(d){var g=b.getUrl;b.getUrl=function(a){return d.call(b,a)||g.call(b,a)}}return b}());
/* jscs:enable */
/* jshint ignore:end */

if ( CKEDITOR.loader )
	CKEDITOR.loader.load( 'ckeditor' );
else {
	// Set the script name to be loaded by the loader.
	CKEDITOR._autoLoad = 'ckeditor';

	// Include the loader script.
	if ( document.body && ( !document.readyState || document.readyState == 'complete' ) ) {
		var script = document.createElement( 'script' );
		script.type = 'text/javascript';
		script.src = CKEDITOR.getUrl( 'core/loader.js' );
		document.body.appendChild( script );
	} else {
		document.write( '<script type="text/javascript" src="' + CKEDITOR.getUrl( 'core/loader.js' ) + '"></script>' );
	}

}

/**
 * The skin to load for all created instances, it may be the name of the skin
 * folder inside the editor installation path, or the name and the path separated
 * by a comma.
 *
 * **Note:** This is a global configuration that applies to all instances.
 *
 *		CKEDITOR.skinName = 'moono';
 *
 *		CKEDITOR.skinName = 'myskin,/customstuff/myskin/';
 *
 * @cfg {String} [skinName='moono-lisa']
 * @member CKEDITOR
 */
CKEDITOR.skinName = 'moono-lisa';

















(function(a) {
    function b(a, b) {
        var c = (a & 65535) + (b & 65535);
        return (a >> 16) + (b >> 16) + (c >> 16) << 16 | c & 65535
    }
    function c(a, c, e, f, g, l) {
        a = b(b(c, a), b(f, l));
        return b(a << g | a >>> 32 - g, e)
    }
    function e(a, b, e, f, g, l, r) {
        return c(b & e | ~b & f, a, b, g, l, r)
    }
    function f(a, b, e, f, g, l, r) {
        return c(b & f | e & ~f, a, b, g, l, r)
    }
    function g(a, b, e, f, g, l, r) {
        return c(e ^ (b | ~f), a, b, g, l, r)
    }
    function l(a, l) {
        a[l >> 5] |= 128 << l % 32;
        a[(l + 64 >>> 9 << 4) + 14] = l;
        var r, h, K, G, C, n = 1732584193, t = -271733879, p = -1732584194, q = 271733878;
        for (r = 0; r < a.length; r += 16)
            h = n,
            K = t,
            G = p,
            C = q,
            n = e(n, t, p, q, a[r], 7, -680876936),
            q = e(q, n, t, p, a[r + 1], 12, -389564586),
            p = e(p, q, n, t, a[r + 2], 17, 606105819),
            t = e(t, p, q, n, a[r + 3], 22, -1044525330),
            n = e(n, t, p, q, a[r + 4], 7, -176418897),
            q = e(q, n, t, p, a[r + 5], 12, 1200080426),
            p = e(p, q, n, t, a[r + 6], 17, -1473231341),
            t = e(t, p, q, n, a[r + 7], 22, -45705983),
            n = e(n, t, p, q, a[r + 8], 7, 1770035416),
            q = e(q, n, t, p, a[r + 9], 12, -1958414417),
            p = e(p, q, n, t, a[r + 10], 17, -42063),
            t = e(t, p, q, n, a[r + 11], 22, -1990404162),
            n = e(n, t, p, q, a[r + 12], 7, 1804603682),
            q = e(q, n, t, p, a[r + 13], 12, -40341101),
            p = e(p, q, n, t, a[r + 14], 17, -1502002290),
            t = e(t, p, q, n, a[r + 15], 22, 1236535329),
            n = f(n, t, p, q, a[r + 1], 5, -165796510),
            q = f(q, n, t, p, a[r + 6], 9, -1069501632),
            p = f(p, q, n, t, a[r + 11], 14, 643717713),
            t = f(t, p, q, n, a[r], 20, -373897302),
            n = f(n, t, p, q, a[r + 5], 5, -701558691),
            q = f(q, n, t, p, a[r + 10], 9, 38016083),
            p = f(p, q, n, t, a[r + 15], 14, -660478335),
            t = f(t, p, q, n, a[r + 4], 20, -405537848),
            n = f(n, t, p, q, a[r + 9], 5, 568446438),
            q = f(q, n, t, p, a[r + 14], 9, -1019803690),
            p = f(p, q, n, t, a[r + 3], 14, -187363961),
            t = f(t, p, q, n, a[r + 8], 20, 1163531501),
            n = f(n, t, p, q, a[r + 13], 5, -1444681467),
            q = f(q, n, t, p, a[r + 2], 9, -51403784),
            p = f(p, q, n, t, a[r + 7], 14, 1735328473),
            t = f(t, p, q, n, a[r + 12], 20, -1926607734),
            n = c(t ^ p ^ q, n, t, a[r + 5], 4, -378558),
            q = c(n ^ t ^ p, q, n, a[r + 8], 11, -2022574463),
            p = c(q ^ n ^ t, p, q, a[r + 11], 16, 1839030562),
            t = c(p ^ q ^ n, t, p, a[r + 14], 23, -35309556),
            n = c(t ^ p ^ q, n, t, a[r + 1], 4, -1530992060),
            q = c(n ^ t ^ p, q, n, a[r + 4], 11, 1272893353),
            p = c(q ^ n ^ t, p, q, a[r + 7], 16, -155497632),
            t = c(p ^ q ^ n, t, p, a[r + 10], 23, -1094730640),
            n = c(t ^ p ^ q, n, t, a[r + 13], 4, 681279174),
            q = c(n ^ t ^ p, q, n, a[r], 11, -358537222),
            p = c(q ^ n ^ t, p, q, a[r + 3], 16, -722521979),
            t = c(p ^ q ^ n, t, p, a[r + 6], 23, 76029189),
            n = c(t ^ p ^ q, n, t, a[r + 9], 4, -640364487),
            q = c(n ^ t ^ p, q, n, a[r + 12], 11, -421815835),
            p = c(q ^ n ^ t, p, q, a[r + 15], 16, 530742520),
            t = c(p ^ q ^ n, t, p, a[r + 2], 23, -995338651),
            n = g(n, t, p, q, a[r], 6, -198630844),
            q = g(q, n, t, p, a[r + 7], 10, 1126891415),
            p = g(p, q, n, t, a[r + 14], 15, -1416354905),
            t = g(t, p, q, n, a[r + 5], 21, -57434055),
            n = g(n, t, p, q, a[r + 12], 6, 1700485571),
            q = g(q, n, t, p, a[r + 3], 10, -1894986606),
            p = g(p, q, n, t, a[r + 10], 15, -1051523),
            t = g(t, p, q, n, a[r + 1], 21, -2054922799),
            n = g(n, t, p, q, a[r + 8], 6, 1873313359),
            q = g(q, n, t, p, a[r + 15], 10, -30611744),
            p = g(p, q, n, t, a[r + 6], 15, -1560198380),
            t = g(t, p, q, n, a[r + 13], 21, 1309151649),
            n = g(n, t, p, q, a[r + 4], 6, -145523070),
            q = g(q, n, t, p, a[r + 11], 10, -1120210379),
            p = g(p, q, n, t, a[r + 2], 15, 718787259),
            t = g(t, p, q, n, a[r + 9], 21, -343485551),
            n = b(n, h),
            t = b(t, K),
            p = b(p, G),
            q = b(q, C);
        return [n, t, p, q]
    }
    function r(a) {
        var b, c = "";
        for (b = 0; b < 32 * a.length; b += 8)
            c += String.fromCharCode(a[b >> 5] >>> b % 32 & 255);
        return c
    }
    function h(a) {
        var b, c = [];
        c[(a.length >> 2) - 1] = void 0;
        for (b = 0; b < c.length; b += 1)
            c[b] = 0;
        for (b = 0; b < 8 * a.length; b += 8)
            c[b >> 5] |= (a.charCodeAt(b / 8) & 255) << b % 32;
        return c
    }
    function G(a) {
        return r(l(h(a), 8 * a.length))
    }
    function C(a, b) {
        var c, e = h(a), f = [], g = [];
        f[15] = g[15] = void 0;
        16 < e.length && (e = l(e, 8 * a.length));
        for (c = 0; 16 > c; c += 1)
            f[c] = e[c] ^ 909522486,
            g[c] = e[c] ^ 1549556828;
        c = l(f.concat(h(b)), 512 + 8 * b.length);
        return r(l(g.concat(c), 640))
    }
    function t(a) {
        var b = "", c, e;
        for (e = 0; e < a.length; e += 1)
            c = a.charCodeAt(e),
            b += "0123456789abcdef".charAt(c >>> 4 & 15) + "0123456789abcdef".charAt(c & 15);
        return b
    }
    function n(a, b, c) {
        b ? c ? a = C(unescape(encodeURIComponent(b)), unescape(encodeURIComponent(a))) : (a = C(unescape(encodeURIComponent(b)), unescape(encodeURIComponent(a))),
        a = t(a)) : a = c ? G(unescape(encodeURIComponent(a))) : t(G(unescape(encodeURIComponent(a))));
        return a
    }
    "function" === typeof define && define.amd ? define(function() {
        return n
    }) : a.md5 = n
}
)(window);