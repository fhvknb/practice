/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.dialog.add( 'about', function( editor ) {
	var lang = editor.lang.about,
		imagePath = CKEDITOR.getUrl( CKEDITOR.plugins.get( 'about' ).path + 'dialogs/' + ( CKEDITOR.env.hidpi ? 'hidpi/' : '' ) + 'logo_ckeditor.png' );

	return {
		title: '小笔袋+快捷键说明',
		minWidth: 390,
		minHeight: 210,
		contents: [ {
			id: 'tab1',
			label: '',
			title: '',
			expand: true,
			padding: 0,
			elements: [
				{
					type: 'html',
					html: [
	                    '<div style="line-height: 18px;">',
	                    '<h1 style="font-size: 20px; display: none;">快捷键说明</h1>',
	                    '<p style="line-height: 20px;">退出命令：按 ESC</p>',
	                    '<p style="line-height: 20px;">撤消命令：按 Command+Z</p>',
	                    '<p style="line-height: 20px;">重做命令：按 Command+Y或者Shift+Command+Z</p>',
	                    '<p style="line-height: 20px;">加粗命令：按 Command+B</p>',
	                    '<p style="line-height: 20px;">倾斜命令：按 Command+I</p>',
	                    '<p style="line-height: 20px;">下划命令：按 Command+U</p>',
	                    '<p style="line-height: 20px;">链接命令：按 Command+L</p>',
	                    '<p style="line-height: 20px;">取消链接命令：按 Shift+Command+L</p>',
	                    '<p style="line-height: 20px;">粘贴为纯文本：按 Shift+Command+V</p>',
	                    '<p style="line-height: 20px;">全屏/退出全屏：按 Command+Enter</p>',
	                    '<p style="line-height: 20px;">图片上传：按 Shift+Command+P（选中图片按快捷键，可快速编辑图片）</p>',
	                    '</div>'
	                ].join('')
				}
			]
		} ],
		buttons: [ CKEDITOR.dialog.cancelButton ]
	};
} );
