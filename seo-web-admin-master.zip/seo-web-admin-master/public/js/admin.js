var $doc = $(document);

//格式化json
function jsonParse(val) {
  try {
    return JSON.parse(val);
  } catch (e) {
    return val;
  }
}

//初始化复制数据
function clipboardInit(el) {
  //若有这个对象，销毁
  if (window.clipboard) {
    window.clipboard.destroy();
  }
  //复制花材数据
  window.clipboard = new Clipboard(el || '.btn-copy', {
    text: function (trigger) {
      var value = $(trigger).attr('data-value');
      return value;
    }
  }).on('success', function (e) {
    layer.msg('复制成功！', {
      icon: 1
    });
    e.clearSelection();
  });
}

//只允许输了数字
$doc.on('input', '.input-sort', function (e) {
  $(this).val(e.target.value.replace(/\D/g, ''));
});

//上传图片
$doc.on('change', '.btn-upload-widget :file.btn-upload-img', function (e) {
  var id = $(this).attr('data-id');
  var isOnly = $(this).attr('data-only') === 'true';
  var imageId = $(this).attr('data-image-id');
  var files = e.target.files;
  var file = e.target.files[0];
  var formData = new FormData();

  for(var i = 0; i < files.length; i++){
    var file = files[i];
    formData.append('file', file);

    // 限制上传图片文件
    if(!file || !file.type || !/(?:jpg|gif|png|jpeg|svg)$/i.test(file.type)){
      layer.msg("请选择正确图片文件！");
      return false;
    }
  }

  if(window.FileReader){
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function(e){
      $.ajax({
        url: '/uploadImage.do',
        method: 'POST',
        data: formData,
        contentType: false, // 注意这里应设为false
        processData: false,
        cache: false
      }).done(function(rsp) {
        if(rsp && rsp.url){
          var $target = $('#' + id);
          var $image = $('#' + imageId);
          rsp.url = rsp.url || '';


          var oldVal = $target.val() || '';
          if(isOnly){
            oldVal = rsp.url;
          }else{
            if(typeof rsp.url === 'string'){
              rsp.url = rsp.url.split(',');
            }
            rsp.url.forEach(function(url){
              if(!oldVal){
                oldVal = url;
              }
              else if(oldVal.indexOf(url) === -1){
                oldVal += ',' + url;
              }
            });
          }

          $target.val(oldVal);
          $image.attr('src', oldVal);
        }
      }).fail(function(rsp) {
        layer.msg("图片上传失败！");
      })
    };
    reader.onerror = function(err) {
        layer.msg("图片上传失败, 请重试");
    };
  }
});

//初始化
$doc.ready(function () {
  //禁止浏览器自动记忆
  setTimeout(function () {
    $('input').attr('autocomplete', 'off');
  }, 2000);

  //获取设备指纹id
  new Fingerprint2().get(function (result, components) {
    window.fpDeviceId = result;
    Cookies.set('deviceId', result);
  });
})
