const os = require('os');

const port = 7001;
const name = 'seo-web-admin';
const adminUsername = 'seo';
const adminPassword = 'seo';
const ip = getIp();

//当前环境
const env = process.env.env || process.env.NODE_ENV || 'dev';
const isProduction = env === 'production';       //是否线上环境
const isTest = env === 'test';                   //是否测试环境
const isDev = env === 'dev';                     //是否本地开发环境


const sessionKey = '2dubao-service-auth:session';        //缓存redis中的key
const sessionCookieKey = '2dubao-service-auth-cookie';   //前端cookie的key
const sessionExpires = 60 * 24 * 60 * 60 * 1000;    //30天后超时


const apiAppKey = '2j233grgr3g3gedfsdf80973223g345g';    //HTTP通信传递  appKey为固定值
const apiSecret = '325ll4to0dsig90s978as6jbcnvb1242';    //HTTP通信传递  secret为固定值
const apiToken = '45jkh8f83-4535-4jdf-g54v4sdd-fgfgfdg'; //HTTP通信传递  token是可变的


//页面中的a标签锚文本链接，推荐使用绝对路径-www pc站点
const webHost = {
    'production': 'https://www.xbidai.com',
    'test': 'https://test.xbidai.com',
    'dev': ['http://', ip, ':', 7002].join('')
}[env];

//页面中的a标签锚文本链接，推荐使用绝对路径-m移动站点
const mHost = {
    'production': 'https://m.xbidai.com',
    'test': 'https://testm.xbidai.com',
    'dev': ['http://', ip, ':', 7003].join('')
}[env];

//s3存储
const s3Option = {
  region: "cn-northwest-1",
  params: {
    Bucket: "mm-seo/" + (isProduction ? 'prod' : 'test')
  },
  accessKeyId: "AKIAPE4FX4OFIGSY3IWQ",
  secretAccessKey: "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"
}

//oss 存储
const ossOption = {
  cdnRootDir: 'seo',
  accessKeyId: 'LTAIcJzGb9YS8DVg',
  accessKeySecret: 'SyUwI3edRXRLN68hcXrheTnDcJDndY',
  bucket: isProduction ? 'mmszprod' : 'mmsztest',
  region: 'oss-cn-shenzhen',
}

//静态资源中的域名路径
const cdnHost = {
  'production': 'https://s.maimangup.com',
  'test': 'https://ts.maimangup.com',
  'dev': 'https://ts.maimangup.com'
}[env];

//登录页面url
const loginUrl = {
  'production': 'https://shortadmin.2dubao.io/admin/login.html',
  'test': 'https://shortadmin.2dubao.io/admin/login.html',
  'dev': ['http://', ip, ':', '7011/admin/login.html'].join('')
}[env];

//注销页面url
const loginUrlOut = {
  'production': 'https://shortadmin.2dubao.io/admin/login-out.html',
  'test': 'https://shortadmin.2dubao.io/admin/login-out.html',
  'dev': ['http://', ip, ':', '7011/admin/login-out.html'].join('')
}[env];

//redis配置属性
const redisOption = {
  production: {
    port: 6379,
    host: 'r-wz970ddbb29a5e24.redis.rds.aliyuncs.com',
    pwd: '123456Xx'
  },
  dev: {
    port: 6379,
    host: '192.168.155.161',
    pwd: ''
  }
}[env] || {};

//mysql配置属性
const mysqlOption = {
    production: {
      host: 'rm-wz9ltd82wo3894mjf.mysql.rds.aliyuncs.com',
      user: 'seo_prod',
      password: '9b389919b8c',
      database: 'seodb',
      port: 3306
    },
    // 外网连接
    dev: {
      host: '192.168.155.161',
      user: 'test3',
      password: 'test3',
      database: 'seodb',
      port: 3306
    }
}[env];

//获取本机IP
function getIp(){
    var IPv4 = '127.0.0.1';
    (os.networkInterfaces().en0 || os.networkInterfaces().eth0 || []).forEach(function (item) {
        if(item.family=='IPv4'){
            IPv4 = item.address;
        }
    });
    return IPv4;
};

module.exports = {
  sessionKey, sessionCookieKey, sessionExpires,
  adminUsername, adminPassword, ip, webHost, mHost, loginUrl, loginUrlOut
  ,port, name, env, isProduction, isTest, isDev, s3Option, ossOption, redisOption, mysqlOption, cdnHost
  ,apiAppKey, apiSecret, apiToken
}
