# 小笔袋seo后台管理中心

# 安装环境
> nodejs 8.x+


# 配置说明
1. 参考config.js
2. 登录用户名密码请参考config.js

# 前端开发注意
1. public/plugins文件夹下的layui、ckeditor插件禁止升级，修改了部分源代码


# 启动
1. 进入【seo-web-admin】文件夹
2. 执行 npm install or yarn
3. 执行 npm start
4. 访问 http://127.0.0.1:7001/admin
5. 内部自动生成的api文档地址 https://s3.cn-northwest-1.amazonaws.com.cn/mm-seo/test/seo-api-docs/index.html

# 文档命令
1. npm run apidoc 生成api文档，并自动生成api文档并上传到aws s3
2. npm run watch 监控【api】变化，并自动生成api文档并上传到aws s3

# 线上发布
1. npm run push push代码到生产环境（禁止使用此命令）
2. npm run build 登录生产机后，一键部署发布（禁止使用此命令）

# 日志系统
```
/log 按日期命名记录日志
```


```
状态码
0		 0: 成功
1		 1: 失败
1000     10001: 签名出错
1100     11001: 系统出错, 11002: 请求太频繁
1200     12001: 参数不能为空  12002:参数验证失败
1300     13001: 系统唯一约束. 13002:数据库数据已存在
```
