const util = require("../util/util.js");
const {webHost, mHost, isProduction, loginUrl} = require("../config.js");
import * as ajaxResult from '../util/ajaxResult';
import * as api from '../util/api';
import userService from '../service/userService';

//中间件-登录鉴权
async function authentication(ctx, next) {
    let url = ctx.url || '';
    let href = ctx.href || '';
    let isAjax = url.indexOf('.do') > -1? true: false;
    ctx.request.data = ctx.method === 'POST'? ctx.request.body: ctx.request.query;
    const user = ctx.session.user;
    const authGroup = await userService.getUserAuth1();
    const {pagepath} = util.getPageParams(ctx);

    const {username, authType, status} = user || {};
    //注意router可以重写这个属性
    ctx.state = {
        webHost, mHost,
        username,
        redirect: '',
        page: '',
        pageChild: ''
    };

    //权限控制-若不是超级管理员，判断权限并跳转
    if(user && authType !== 1 && !authGroup[pagepath] || status === 2){
      if(isAjax){
        ctx.body = ajaxResult.auth();
      }else{
        await ctx.render('auth');
      }
      return;
    }

    //若是内部的API调用
    if(url.indexOf('/api/v1/') > -1){
      const verifyRsp = await api.verifySign(ctx.request.data);

      //若签名验证失败
      if(!verifyRsp.isOk){
        ctx.body = ajaxResult.error(verifyRsp.msg, null);
        return;
      }

      ctx.request.data = verifyRsp.data
      await next();
    }
    //若是正常的登录用户操作
    else if( user || checkoutUrlAuth(['/user/login.do', '/admin/login.html'], url)){
      await next();
    }
    //若后缀为.do，则返回接口形式的登录提示
    else if(isAjax){
      ctx.body = ajaxResult.login();
    }else{
      if(isProduction){
        ctx.redirect(loginUrl + '?redirect=' + encodeURIComponent(href.replace('http://', 'https://')));
      }else{
        ctx.redirect(loginUrl + '?redirect=' + encodeURIComponent(href));
      }
      //await ctx.render('login');
    }
}

//验证数组中多个url
function checkoutUrlAuth(arr = [], url = ''){
    return arr.filter(item => url.indexOf(item) > -1).length > 0;
}

module.exports = authentication;
