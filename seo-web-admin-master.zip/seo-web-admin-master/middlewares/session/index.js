const sessionStore = require('./sessionStore.js');
const { sessionCookieKey, sessionExpires, isProduction } = require('../../config');

function store() {
  const opts = {
    key: sessionCookieKey, //default "koa:sess"
    store: sessionStore,
    maxAge: sessionExpires,
    domain: isProduction? '2dubao.io': '',
    expires: new Date(new Date().getTime() + sessionExpires), //默认30天后超时
  }
  const { key, store } = opts;

  return async (ctx, next) => {
    let id = ctx.cookies.get(key, opts);

    if (!id) {
      ctx.session = {};
    } else {
      ctx.session = await store.get(id, ctx);

      //若redis缓存用户过期，删除cookies
      if (!ctx.session || !ctx.session.user) {
        await store.destroy(id);
        ctx.cookies.set(key, null);
      }

      // check session must be a no-null object
      if (typeof ctx.session !== "object" || ctx.session == null) {
        ctx.session = {};
      }
    }

    const old = JSON.stringify(ctx.session);

    // add refresh function
    let need_refresh = false
    ctx.session.refresh = () => {
      need_refresh = true
    }
    ctx.session.createSid = function (session = {}) {
      ctx.session.sid = id || session.id || store.createSid();
      return ctx.session.sid;
    };

    await next();

    // remove refresh function
    if (ctx.session && 'refresh' in ctx.session) {
      delete ctx.session.refresh
    }

    const sess = JSON.stringify(ctx.session);

    // if not changed
    if (!need_refresh && old == sess) return;

    // if is an empty object
    if (sess == '{}') {
      ctx.session = null;
    }

    // need clear old session
    if (id && !ctx.session) {
      await store.destroy(id, ctx);
      ctx.cookies.set(key, null);
      return;
    }

    // set/update session
    const sid = await store.set(ctx.session, Object.assign({}, opts, {
      sid: id
    }), ctx);
    ctx.cookies.set(key, sid, opts);
  }
}

module.exports = store();
