//const Redis = require("ioredis");
const redis = require("../../util/redis");
const Store = require("./store");
const {sessionKey, sessionExpires} = require('../../config');


class RedisStoreClass extends Store {
    constructor() {
        super();
    }

    createSid() {
        return this.getID(24);
    }

    async get(sid) {
        return await redis.get(`${sessionKey}:${sid}`);
    }

    async set(session = {}, {sid, maxAge} = {}) {
        if(!session.sid) {
            session.sid = this.createSid();
        }

        sid = sid || session.sid;
        await this.setSession(sid, session, maxAge / 1000);
        return session.sid;
    }

    async setSession(sid, session, expire) {
        if(session && session.password){
            delete session.password;
        }

        return await redis.set(`${sessionKey}:${sid}`, session, expire);
    }

    //重置用户的登录态
    async setUser(sid, session, expire = sessionExpires / 1000) {
        const data = await this.get(sid);

        if(data && data.user){
            data.user = session;
        }

        return await redis.set(`${sessionKey}:${sid}`, data, expire);
    }

    async destroy(sid) {
        return await redis.del(`${sessionKey}:${sid}`);
    }
}


module.exports = new RedisStoreClass();
