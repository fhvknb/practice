const path = require("path");
const moment = require('moment');
const colors = require('colors');
const util = require('../util/util');
const {name} = require('../config');

util.mkdir(path.join(__dirname, '../output'));
util.mkdir(path.join(__dirname, '../log'));

const logger = require('mini-logger')({
    dir: 'log',
    categories: [ 'log', 'warn'],
    format: 'YYYY-MM-DD-[{category}][.log]'
});

colors.setTheme({
  silly: 'rainbow',
  input: 'grey',
  verbose: 'cyan',
  prompt: 'grey',
  info: 'green',
  data: 'grey',
  help: 'cyan',
  warn: 'yellow',
  debug: 'blue',
  error: 'red'
});


global.logger = {
  log: (...val)=> console.log(colors.info(`[${name}-${moment().format('YYYY-MM-DD HH:mm:ss')}] ` + val)) || logger.log(`[${name}-${moment().format('YYYY-MM-DD HH:mm:ss')}] ` + val),
  error: (...val)=> console.log(colors.error(`[${name}-${moment().format('YYYY-MM-DD HH:mm:ss')}] ` + val)) || logger.error(`[${name}-${moment().format('YYYY-MM-DD HH:mm:ss')}] ` + val),
  warn: (...val)=> console.log(colors.warn(`[${name}-${moment().format('YYYY-MM-DD HH:mm:ss')}] ` + val)) || logger.warn(`[${name}-${moment().format('YYYY-MM-DD HH:mm:ss')}] ` + val),
};


module.exports = logger;
