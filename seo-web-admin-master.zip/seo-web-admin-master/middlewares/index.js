const session = require("./session");
const authentication = require("./authentication");
const requestLog = require("./requestLog");
const logger = require("./logInit");


export default function(app){

    //中间件-session管理  修改了源代码，参考https://github.com/Secbone/koa-session2
    app.use(session);

    //中间件-日志记录
    app.use(requestLog);

    //中间件-登录验证
    app.use(authentication);
}
