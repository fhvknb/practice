const util = require("../util/util.js");
import * as trackService from '../service/trackService';

//中间件-日志记录
async function requestLog(ctx, next) {
  const start = new Date();
  const ip = util.getIp(ctx);

  await next();

  const loggerType = { '404': 'warn', '500': 'error' }[ctx.status] || 'log';
  const time = new Date() - start;
  const href = ctx.href;
  global.logger[loggerType](`[${ip}] ${ctx.status} ${ctx.method} ${href} - ${time}ms`);

  await trackService.trackPageView(ctx, {
    property: JSON.stringify(ctx.request.data),
    value: time
  })
}

module.exports = requestLog;
