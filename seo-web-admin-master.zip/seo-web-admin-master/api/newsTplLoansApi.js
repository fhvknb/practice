import * as ajaxResult from '../util/ajaxResult';
import newsTplLoansMapService from '../service/newsTplLoansMapService';



/**
 * @apiDefine newsTplLoansGroup 模版资讯问答管理
 */

/**
 * @api {post} /api/v1/newsTplLoans/findListByPage 分页获取资讯问答列表
 * @apiVersion 1.0.0
 * @apiName findListByPage
 * @apiGroup newsTplLoansGroup
 * @apiParam {String} loansId 贷款产品id，必填
 * @apiParam {String} pageIndex=1 分页索引
 * @apiParam {String} pageSize=50 每页显示数量
 * @apiParam {String} sortField=null 排序字段 sortField可为空，若设值的话sortType也必须设值
 * @apiParam {String} sortType=null 排序方式 desc/asc sortType可为空，若设值的话sortField也必须设值
 * @apiParam {String} startCreateDate=null 创建时间-开始范围
 * @apiParam {String} endCreateDate=null 创建时间-结束范围

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/newsTplLoans/findListByPage', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
  {
    "data": {
      "data": [
        {
            "id": 81,
            "loansId": 71,
            "newsTplId": 1,
            "type": 2,
            "classifyId": 6,
            "tagId": "9,8,6",
            "name": "爱贝信靠谱吗？",
            "isOriginal": 1,
            "author": "",
            "source": "网络整合",
            "content": "<p>爱贝信靠谱吗/怎么样/可靠吗/是什么？</p>\n\n<p>&nbsp;</p>\n\n<p>摘要：爱贝信是一款大家都知道的P2P网络贷款平台，那么XXX究竟可靠吗？</p>\n\n<p>正文：</p>\n\n<p>&nbsp;</p>\n\n<p>产品：诺米借</p>\n\n<p>&nbsp;</p>\n\n<p>爱贝信是一款手机综合金融贷款平台，用户可以通过下载XXXX APP即可申请贷款，通过互联网、大数据等科技手段，利用智能和大数据风控技术，为20岁以上的用户人群提供安心、便捷的贷款服务。</p>\n\n<p>&nbsp;</p>\n\n<p>以下是关于爱贝信的产品介绍</p>\n\n<p>&nbsp;</p>\n\n<p>一、产品介绍</p>\n\n<p>放款速度：&nbsp;&nbsp; 快至10分钟</p>\n\n<p>可借额度：&nbsp;&nbsp; 1000-5000</p>\n\n<p>借款期限：&nbsp;&nbsp; 7天-30天</p>\n\n<p>放款数量：&nbsp;&nbsp; 42134</p>\n\n<p>贷款日利率： 0.05%</p>\n\n<p>&nbsp;</p>\n\n<p>二、审核方式</p>\n\n<p>审核时间：10分钟；</p>\n\n<p>放款时间：10分钟</p>\n\n<p>&nbsp;</p>\n\n<p>三、申请条件</p>\n\n<p>无网贷逾期；</p>\n\n<p>手机实名6个月以上；</p>\n\n<p>负债2万以内；</p>\n\n<p>年龄20-55周岁；</p>\n\n<p>&nbsp;</p>\n\n<p>这样看来，爱贝信在众多的网络贷款平台中是相当可靠、靠谱、正规的平台。</p>\n",
            "image": "",
            "digest": "爱贝信靠谱吗/怎么样/可靠吗/是什么？",
            "view": 0,
            "seoTitle": "爱贝信靠谱吗？ - 攻略 - 小笔袋",
            "seoKeywords": "投资理财,玩卡攻略,贷款",
            "seoDescription": "爱贝信靠谱吗/怎么样/可靠吗/是什么？",
            "createTime": "2018-12-11 16:03:48",
            "updateTime": null,
            "classify": "攻略",
            "tagIdArr": [
                "9",
                "8",
                "6"
            ],
            "tagArr": [
                {
                    "id": 9,
                    "name": "投资理财",
                    "path": null,
                    "createTime": "2018-10-22 11:31:45"
                },
                {
                    "id": 8,
                    "name": "玩卡攻略",
                    "path": null,
                    "createTime": "2018-10-22 11:31:22"
                },
                {
                    "id": 6,
                    "name": "贷款",
                    "path": null,
                    "createTime": "2018-10-22 11:31:04"
                }
            ],
            "typeText": "问答",
            "image3": "",
            "image2": "",
            "image1": "",
            "murl": "http://192.168.156.108:7003/wenda/wenda_81.html",
            "wwwurl": "http://192.168.156.108:7002/wenda/wenda_81.html",
            "publishTime": "2018-12-11 16:03:48",
            "createTimeText": "一小时前"
        },
        {
            "id": 6,
            "loansId": 71,
            "newsTplId": 2,
            "type": 2,
            "classifyId": 9,
            "tagId": "8,7",
            "name": "爱贝信能贷款多少？",
            "isOriginal": 1,
            "author": "",
            "source": "网络整合",
            "content": "<p style=\"text-align:justify\"><span style=\"font-size:10.5pt\"><span style=\"font-family:等线\"><strong>产品：爱贝信</strong></span></span></p>\n\n<p style=\"text-align:justify\">&nbsp;</p>\n\n<p style=\"text-align:justify\"><span style=\"font-size:10.5pt\"><span style=\"font-family:等线\">爱贝信是值得信赖的专业P2P网络贷款平台，拥有专业化的借贷服务和品质化的管理中心，不仅如此，在XXXX申请网贷不仅审核速度快，还秒批到账，是急需用钱人的首选，那XXXX最少能贷款多少呢？</span></span></p>\n\n<p style=\"text-align:justify\">&nbsp;</p>\n\n<p style=\"text-align:justify\"><span style=\"font-size:10.5pt\"><span style=\"font-family:等线\">根据爱贝信的渠道了解，爱贝信的最高借款金额为<strong>2000</strong>元，最少为<strong>1000</strong>元，也就是说它的可借额度是<strong>1000-2000</strong>元，是小额贷款中的优质选择！</span></span></p>\n",
            "image": "https://ts.maimangup.com/seo/upload/images/9/f0/9f060a6a407fd1a51335c2a876b867b4.jpeg",
            "digest": "爱贝信是一款值得信赖的专业P2P网络贷款，并且审核速度快、秒批到账，那么XXXX最少能贷款多少？最多能贷款多少呢？",
            "view": 0,
            "seoTitle": "爱贝信能贷款多少？ - 房产 - 小笔袋",
            "seoKeywords": "玩卡攻略,微粒贷",
            "seoDescription": "爱贝信是一款值得信赖的专业P2P网络贷款，并且审核速度快、秒批到账，那么XXXX最少能贷款多少？最多能贷款多少呢？",
            "createTime": "2018-12-11 16:03:46",
            "updateTime": null,
            "classify": "房产",
            "tagIdArr": [
                "8",
                "7"
            ],
            "tagArr": [
                {
                    "id": 8,
                    "name": "玩卡攻略",
                    "path": null,
                    "createTime": "2018-10-22 11:31:22"
                },
                {
                    "id": 7,
                    "name": "微粒贷",
                    "path": null,
                    "createTime": "2018-10-22 11:31:09"
                }
            ],
            "typeText": "问答",
            "image3": "https://ts.maimangup.com/seo/upload/images/9/f0/9f060a6a407fd1a51335c2a876b867b4.jpeg?x-oss-process=image/resize,w_1200",
            "image2": "https://ts.maimangup.com/seo/upload/images/9/f0/9f060a6a407fd1a51335c2a876b867b4.jpeg?x-oss-process=image/resize,w_820",
            "image1": "https://ts.maimangup.com/seo/upload/images/9/f0/9f060a6a407fd1a51335c2a876b867b4.jpeg?x-oss-process=image/resize,w_300",
            "murl": "http://192.168.156.108:7003/wenda/wenda_6.html",
            "wwwurl": "http://192.168.156.108:7002/wenda/wenda_6.html",
            "publishTime": "2018-12-11 16:03:46",
            "createTimeText": "一小时前"
        }
      ],
      "pageIndex": 1,
      "pageSize": 10,
      "pageCount": 1,
      "totalCount": 2
    },
    "msg": "获取数据列表成功",
    "code": 0
  }
 */

export async function findListByPage (ctx) {
  const rsp = await newsTplLoansMapService.findListByPage(ctx.request.data);
  ctx.body = ajaxResult.ok('获取数据列表成功', rsp);
};


/**
 * @api {post} /api/v1/newsTplLoans/findById 根据id获取资讯问答详情
 * @apiVersion 1.0.0
 * @apiName findById
 * @apiGroup newsTplLoansGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/newsTplLoans/findById', {id: 2});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数id不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
          "id": 95,
          "loansId": 57,
          "newsTplId": 1,
          "type": 2,
          "classifyId": 6,
          "tagId": "9,8,6",
          "name": "蟋蟀易贷靠谱吗？",
          "isOriginal": 1,
          "author": "",
          "source": "网络整合",
          "content": "<p>蟋蟀易贷靠谱吗/怎么样/可靠吗/是什么？</p>\n\n<p>&nbsp;</p>\n\n<p>摘要：蟋蟀易贷是一款大家都知道的P2P网络贷款平台，那么XXX究竟可靠吗？</p>\n\n<p>正文：</p>\n\n<p>&nbsp;</p>\n\n<p>产品：诺米借</p>\n\n<p>&nbsp;</p>\n\n<p>蟋蟀易贷是一款手机综合金融贷款平台，用户可以通过下载XXXX APP即可申请贷款，通过互联网、大数据等科技手段，利用智能和大数据风控技术，为20岁以上的用户人群提供安心、便捷的贷款服务。</p>\n\n<p>&nbsp;</p>\n\n<p>以下是关于蟋蟀易贷的产品介绍</p>\n\n<p>&nbsp;</p>\n\n<p>一、产品介绍</p>\n\n<p>放款速度：&nbsp;&nbsp; 快至10分钟</p>\n\n<p>可借额度：&nbsp;&nbsp; 1000-5000</p>\n\n<p>借款期限：&nbsp;&nbsp; 7天-30天</p>\n\n<p>放款数量：&nbsp;&nbsp; 42134</p>\n\n<p>贷款日利率： 0.05%</p>\n\n<p>&nbsp;</p>\n\n<p>二、审核方式</p>\n\n<p>审核时间：10分钟；</p>\n\n<p>放款时间：10分钟</p>\n\n<p>&nbsp;</p>\n\n<p>三、申请条件</p>\n\n<p>无网贷逾期；</p>\n\n<p>手机实名6个月以上；</p>\n\n<p>负债2万以内；</p>\n\n<p>年龄20-55周岁；</p>\n\n<p>&nbsp;</p>\n\n<p>这样看来，蟋蟀易贷在众多的网络贷款平台中是相当可靠、靠谱、正规的平台。</p>\n",
          "image": "",
          "digest": "蟋蟀易贷靠谱吗/怎么样/可靠吗/是什么？",
          "view": 0,
          "seoTitle": "",
          "seoKeywords": "",
          "seoDescription": "",
          "createTime": "2018-12-11 16:03:48",
          "updateTime": null
        },
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findById (ctx) {
  const {id} = ctx.request.data;

  if(!id){
      ctx.body = ajaxResult.error('参数id不能为空', null, 12001);
  }else{
      const rsp = await newsTplLoansMapService.findById(id);
      ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};


/**
 * @api {post} /api/v1/newsTplLoans/findByLoansIdAndNewsTplId 根据loansId、newsTplId获取资讯问答详情
 * @apiVersion 1.0.0
 * @apiName findByLoansIdAndNewsTplId
 * @apiGroup newsTplLoansGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/newsTplLoans/findByLoansIdAndNewsTplId', {loansId: 1, newsTplId: 1});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数loansId不能为空
 * @apiError 12002 参数newsTplId不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
          "id": 95,
          "loansId": 57,
          "newsTplId": 1,
          "type": 2,
          "classifyId": 6,
          "tagId": "9,8,6",
          "name": "蟋蟀易贷靠谱吗？",
          "isOriginal": 1,
          "author": "",
          "source": "网络整合",
          "content": "<p>蟋蟀易贷靠谱吗/怎么样/可靠吗/是什么？</p>\n\n<p>&nbsp;</p>\n\n<p>摘要：蟋蟀易贷是一款大家都知道的P2P网络贷款平台，那么XXX究竟可靠吗？</p>\n\n<p>正文：</p>\n\n<p>&nbsp;</p>\n\n<p>产品：诺米借</p>\n\n<p>&nbsp;</p>\n\n<p>蟋蟀易贷是一款手机综合金融贷款平台，用户可以通过下载XXXX APP即可申请贷款，通过互联网、大数据等科技手段，利用智能和大数据风控技术，为20岁以上的用户人群提供安心、便捷的贷款服务。</p>\n\n<p>&nbsp;</p>\n\n<p>以下是关于蟋蟀易贷的产品介绍</p>\n\n<p>&nbsp;</p>\n\n<p>一、产品介绍</p>\n\n<p>放款速度：&nbsp;&nbsp; 快至10分钟</p>\n\n<p>可借额度：&nbsp;&nbsp; 1000-5000</p>\n\n<p>借款期限：&nbsp;&nbsp; 7天-30天</p>\n\n<p>放款数量：&nbsp;&nbsp; 42134</p>\n\n<p>贷款日利率： 0.05%</p>\n\n<p>&nbsp;</p>\n\n<p>二、审核方式</p>\n\n<p>审核时间：10分钟；</p>\n\n<p>放款时间：10分钟</p>\n\n<p>&nbsp;</p>\n\n<p>三、申请条件</p>\n\n<p>无网贷逾期；</p>\n\n<p>手机实名6个月以上；</p>\n\n<p>负债2万以内；</p>\n\n<p>年龄20-55周岁；</p>\n\n<p>&nbsp;</p>\n\n<p>这样看来，蟋蟀易贷在众多的网络贷款平台中是相当可靠、靠谱、正规的平台。</p>\n",
          "image": "",
          "digest": "蟋蟀易贷靠谱吗/怎么样/可靠吗/是什么？",
          "view": 0,
          "seoTitle": "",
          "seoKeywords": "",
          "seoDescription": "",
          "createTime": "2018-12-11 16:03:48",
          "updateTime": null
        },
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByLoansIdAndNewsTplId (ctx) {
  const {loansId, newsTplId} = ctx.request.data;

  if(!loansId){
    ctx.body = ajaxResult.error('参数loansId不能为空', null, 12001);
  }else if(!newsTplId){
    ctx.body = ajaxResult.error('参数newsTplId不能为空', null, 12002);
  }else{
    const rsp = await newsTplLoansMapService.findByLoansIdAndNewsTplId({loansId, newsTplId});
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};


/**
 * @api {post} /api/v1/newsTplLoans/findListByRandom 随机获取x条资讯问答列表
 * @apiVersion 1.0.0
 * @apiName findListByRandom
 * @apiGroup newsTplLoansGroup
 * @apiParam {String} pageSize=10 每页显示数量
 * @apiParam {String} endPublishTime 发布时间，小于这个发布时间的不显示

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/newsTplLoans/findListByRandom', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
      "data": {
        "data": [
          {
            "id": 95,
            "loansId": 57,
            "newsTplId": 1,
            "type": 2,
            "classifyId": 6,
            "tagId": "9,8,6",
            "name": "蟋蟀易贷靠谱吗？",
            "isOriginal": 1,
            "author": "",
            "source": "网络整合",
            "content": "<p>蟋蟀易贷靠谱吗/怎么样/可靠吗/是什么？</p>\n\n<p>&nbsp;</p>\n\n<p>摘要：蟋蟀易贷是一款大家都知道的P2P网络贷款平台，那么XXX究竟可靠吗？</p>\n\n<p>正文：</p>\n\n<p>&nbsp;</p>\n\n<p>产品：诺米借</p>\n\n<p>&nbsp;</p>\n\n<p>蟋蟀易贷是一款手机综合金融贷款平台，用户可以通过下载XXXX APP即可申请贷款，通过互联网、大数据等科技手段，利用智能和大数据风控技术，为20岁以上的用户人群提供安心、便捷的贷款服务。</p>\n\n<p>&nbsp;</p>\n\n<p>以下是关于蟋蟀易贷的产品介绍</p>\n\n<p>&nbsp;</p>\n\n<p>一、产品介绍</p>\n\n<p>放款速度：&nbsp;&nbsp; 快至10分钟</p>\n\n<p>可借额度：&nbsp;&nbsp; 1000-5000</p>\n\n<p>借款期限：&nbsp;&nbsp; 7天-30天</p>\n\n<p>放款数量：&nbsp;&nbsp; 42134</p>\n\n<p>贷款日利率： 0.05%</p>\n\n<p>&nbsp;</p>\n\n<p>二、审核方式</p>\n\n<p>审核时间：10分钟；</p>\n\n<p>放款时间：10分钟</p>\n\n<p>&nbsp;</p>\n\n<p>三、申请条件</p>\n\n<p>无网贷逾期；</p>\n\n<p>手机实名6个月以上；</p>\n\n<p>负债2万以内；</p>\n\n<p>年龄20-55周岁；</p>\n\n<p>&nbsp;</p>\n\n<p>这样看来，蟋蟀易贷在众多的网络贷款平台中是相当可靠、靠谱、正规的平台。</p>\n",
            "image": "",
            "digest": "蟋蟀易贷靠谱吗/怎么样/可靠吗/是什么？",
            "view": 0,
            "seoTitle": "",
            "seoKeywords": "",
            "seoDescription": "",
            "createTime": "2018-12-11 16:03:48",
            "updateTime": null
          }
        ],
        "pageIndex": 1,
        "pageSize": 50,
        "pageCount": 1,
        "totalCount": 3
      },
      "msg": "获取数据列表成功",
      "code": 0
    }
 */

export async function findListByRandom (ctx) {
  const rsp = await newsTplLoansMapService.findListByRandom(ctx.request.data);
  ctx.body = ajaxResult.ok('获取数据列表成功', rsp);
};

/**
 * @api {post} /api/v1/newsTplLoans/updateViewById 根据id更新资讯点击数
 * @apiVersion 1.0.0
 * @apiName updateViewById
 * @apiGroup newsTplLoansGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/newsTplLoans/updateViewById', {id: 2});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数id不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": null,
        "msg": "更新成功",
        "code": 0
    }
 */

export async function updateViewById (ctx) {
  const {id} = ctx.request.data;

  if(!id){
      ctx.body = ajaxResult.error('参数id不能为空', null, 12001);
  }else{
      const rsp = await newsTplLoansMapService.updateViewById(id);
      ctx.body = ajaxResult.ok('更新成功', rsp);
  }
};
