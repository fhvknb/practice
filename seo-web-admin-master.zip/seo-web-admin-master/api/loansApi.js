import * as ajaxResult from '../util/ajaxResult';
import loansService from '../service/loansService';


/**
 * @apiDefine loansGroup 贷款管理
 */

/**
 * @api {post} /api/v1/loans/findListByPage 分页获取贷款列表数据
 * @apiVersion 1.0.0
 * @apiName findListByPage
 * @apiGroup loansGroup
 * @apiParam {String} pageIndex=1 键名
 * @apiParam {String} pageSize=50 键名
 * @apiParam {String} sortField=null 排序字段 sortField可为空，若设值的话sortType也必须设值
 * @apiParam {String} sortType=null 排序方式 desc/asc sortType可为空，若设值的话sortField也必须设值
 * @apiParam {String} id id
 * @apiParam {String} name 贷款产品名称
 * @apiParam {String} ad 贷款产品广告
 * @apiParam {String} href 贷款产品链接
 * @apiParam {String} profitUnit 参考利润单位; 0:月利率  1:日利率
 * @apiParam {String} status 上架状态 0:下架  1:上架
 * @apiParam {String} startCreateDate=null 创建时间-开始范围
 * @apiParam {String} endCreateDate=null 创建时间-结束范围

 * @apiParamExample {json} 请求参数实例:
  const rsp = await api.post('/loans/findListByPage', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
  {
    "data": {
      "data": [
      ],
      "pageIndex": 1,
      "pageSize": 50,
      "pageCount": 1,
      "totalCount": 3
    },
    "msg": "获取数据列表成功",
    "code": 0
  }
 */

export async function findListByPage (ctx) {
  const rsp = await loansService.findListByPage(ctx.request.data);

  ctx.body = ajaxResult.ok('获取数据列表成功', rsp);
};

/**
 * @api {post} /api/v1/loans/findById 根据id获取贷款详情
 * @apiVersion 1.0.0
 * @apiName findById
 * @apiGroup loansGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/loans/findById', {id: 1});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数id不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
          id: 1,
          name: '笔芯钱包',
          ad: '最快10分钟下款',
          href: 'http://author.baidu.com/home/1614537902747053',
          logoUrl: 'https://ts.maimangup.com/seo/upload/images/e/87/e87a4a785c1522123cadc4cdaf87e42c.png',
          creditTime: '10分钟',
          creditTotal: '100000',
          profit: '0.2',
          profitUnit: 0,
          loanLife: '24个月',
          count: '34987',
          material: '身份证',
          presentation: '身份证',
          requirement: '身份证',
          sort: 2,
          status: 0,
          createUser: 'seo',
          createTime: '2018-11-14 17:57:09',
          updateUser: 'seo',
          updateTime: '2018-11-14 19:04:12',
          profitUnitText: '月利率'
        },
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findById (ctx) {
  const {id} = ctx.request.data;

  if(!id){
      ctx.body = ajaxResult.error('参数id不能为空', null, 12001);
  }else{
      const rsp = await loansService.findById(id);
      ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};
