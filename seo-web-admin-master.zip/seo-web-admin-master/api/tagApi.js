import * as ajaxResult from '../util/ajaxResult';
import tagService from '../service/tagService';


/**
 * @apiDefine tagGroup 标签管理
 */

/**
 * @api {post} /api/v1/tag/findByIds 根据ids批量获取标签
 * @apiVersion 1.0.0
 * @apiName findByIds
 * @apiGroup tagGroup
 * @apiParam {Array} ids 数组或者null，若为null默认查询所有

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/tag/findByIds', {ids: [2]});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": [{
                "id": 9,
                "name": "投资理财",
                "createTime": "2018-10-22 11:31:45"
            },
            {
                "id": 8,
                "name": "玩卡攻略",
                "createTime": "2018-10-22 11:31:22"
            },
            {
                "id": 7,
                "name": "微粒贷",
                "createTime": "2018-10-22 11:31:09"
            },
            {
                "id": 6,
                "name": "贷款",
                "createTime": "2018-10-22 11:31:04"
            },
            {
                "id": 5,
                "name": "公积金",
                "createTime": "2018-10-22 11:30:58"
            },
            {
                "id": 2,
                "name": "薅羊毛",
                "createTime": "2018-10-17 16:32:03"
            },
            {
            "id": 1,
            "name": "口子",
            "createTime": "2018-10-17 16:31:48"
        }],
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByIds (ctx) {
    const {ids} = ctx.request.data;

    const rsp = await tagService.findByIds(ids);
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
};
