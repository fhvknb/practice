import * as ajaxResult from '../util/ajaxResult';
import newsService from '../service/newsService';



/**
 * @apiDefine newsGroup 资讯管理
 */

/**
 * @api {post} /api/v1/news/findListByPage 分页获取资讯列表数据
 * @apiVersion 1.0.0
 * @apiName findListByPage
 * @apiGroup newsGroup
 * @apiParam {String} pageIndex=1 分页索引
 * @apiParam {String} pageSize=50 每页显示数量
 * @apiParam {String} sortField=null 排序字段 sortField可为空，若设值的话sortType也必须设值
 * @apiParam {String} sortType=null 排序方式 desc/asc sortType可为空，若设值的话sortField也必须设值
 * @apiParam {String} name=null 资讯名称
 * @apiParam {String} type=null 1:攻略；2:问答；3:百科
 * @apiParam {String} classifyId=null 分类id
 * @apiParam {String} tagId=null 标签id
 * @apiParam {String} startCreateDate=null 创建时间-开始范围
 * @apiParam {String} endCreateDate=null 创建时间-结束范围

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/news/findListByPage', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
            "data": [{
                    "id": 2,
                    "classifyId": 4,
                    "tagId": "2",
                    "name": "微粒贷怎么开通，史上最详细的微粒贷介绍，开通微粒贷只要3分钟",
                    "author": "景天坤德一比",
                    "source": "笔芯信用",
                    "content": "...",
                    "view": null,
                    "createTime": "2018-10-18 14:57:16",
                    "updateTime": "2018-10-18 15:14:57",
                    "tagIdArr": ["2"]
                },{
                    "id": 1,
                    "classifyId": 5,
                    "tagId": "2,1",
                    "name": "深度揭秘：公积金不这么用，你可亏大了！不超过5%的人知道的公积金使用技巧",
                    "author": "景天坤德一比",
                    "source": "笔芯信用",
                    "content": "...",
                    "view": null,
                    "createTime": "2018-10-18 10:41:16",
                    "updateTime": "2018-10-18 15:14:40",
                    "tagIdArr": ["2","1"]
                }
            ],
            "pageIndex": 1,
            "pageSize": 50,
            "pageCount": 1,
            "totalCount": 3
        },
        "msg": "获取数据列表成功",
        "code": 0
    }
 */

export async function findListByPage(ctx) {
  const rsp = await newsService.findListByPage(ctx.request.data);

  ctx.body = ajaxResult.ok('获取数据列表成功', rsp);
};



/**
 * @api {post} /api/v1/news/findListByRandom 随机获取x条资讯列表
 * @apiVersion 1.0.0
 * @apiName findListByRandom
 * @apiGroup newsGroup
 * @apiParam {String} pageSize=10 每页显示数量
 * @apiParam {String} type=null 1:攻略；2:问答；3:百科

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/news/findListByRandom', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
      "data": {
        "data": [{
            "id": 2,
            "classifyId": 4,
            "tagId": "2",
            "name": "微粒贷怎么开通，史上最详细的微粒贷介绍，开通微粒贷只要3分钟",
            "author": "景天坤德一比",
            "source": "笔芯信用",
            "content": "...",
            "view": null,
            "createTime": "2018-10-18 14:57:16",
            "updateTime": "2018-10-18 15:14:57",
            "tagIdArr": ["2"]
          },{
            "id": 1,
            "classifyId": 5,
            "tagId": "2,1",
            "name": "深度揭秘：公积金不这么用，你可亏大了！不超过5%的人知道的公积金使用技巧",
            "author": "景天坤德一比",
            "source": "笔芯信用",
            "content": "...",
            "view": null,
            "createTime": "2018-10-18 10:41:16",
            "updateTime": "2018-10-18 15:14:40",
            "tagIdArr": ["2","1"]
          }
        ],
        "pageIndex": 1,
        "pageSize": 50,
        "pageCount": 1,
        "totalCount": 3
      },
      "msg": "获取数据列表成功",
      "code": 0
    }
 */

export async function findListByRandom(ctx) {
  const rsp = await newsService.findListByRandom(ctx.request.data);
  ctx.body = ajaxResult.ok('获取数据列表成功', rsp);
};

/**
 * @api {post} /api/v1/news/findById 根据id获取资讯详情
 * @apiVersion 1.0.0
 * @apiName findById
 * @apiGroup newsGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/news/findById', {id: 2});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数id不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
            "id": 2,
            "classifyId": 4,
            "tagId": "2",
            "name": "微粒贷怎么开通，史上最详细的微粒贷介绍，开通微粒贷只要3分钟",
            "author": "景天坤德一比",
            "source": "笔芯信用",
            "content": "...",
            "view": null,
            "createTime": "2018-10-18 14:57:16",
            "updateTime": "2018-10-18 15:14:57",
            "tagIdArr": ["2"]
        },
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findById(ctx) {
  const {
    id
  } = ctx.request.data;

  if (!id) {
    ctx.body = ajaxResult.error('参数id不能为空', null, 12001);
  } else {
    const rsp = await newsService.findById(id);
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};

/**
 * @api {post} /api/v1/news/findByIds 根据ids批量获取资讯
 * @apiVersion 1.0.0
 * @apiName findByIds
 * @apiGroup newsGroup
 * @apiParam {Array} ids

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/news/findByIds', {ids: [2]});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数ids不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": [{
            "id": 2,
            "uuid": 20181024111830813170123,
            "classifyId": 4,
            "tagId": "2",
            "name": "微粒贷怎么开通，史上最详细的微粒贷介绍，开通微粒贷只要3分钟",
            "author": "景天坤德一比",
            "source": "笔芯信用",
            "content": "...",
            "view": null,
            "createTime": "2018-10-18 14:57:16",
            "updateTime": "2018-10-18 15:14:57",
            "tagIdArr": ["2"]
        }],
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByIds(ctx) {
  const {
    ids
  } = ctx.request.data;

  if (!Array.isArray(ids) || ids.length === 0) {
    ctx.body = ajaxResult.error('参数ids不能为空', null, 12001);
  } else {
    const rsp = await newsService.findByIds(ids);
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};


/**
 * @api {post} /api/v1/news/findByUuid 根据uuid获取资讯详情
 * @apiVersion 1.0.0
 * @apiName findByUuid
 * @apiGroup newsGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/news/findByUuid', {uuid: 2});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数id不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
            "id": 2,
            "uuid": 20181024111830813170123,
            "classifyId": 4,
            "tagId": "2",
            "name": "微粒贷怎么开通，史上最详细的微粒贷介绍，开通微粒贷只要3分钟",
            "author": "景天坤德一比",
            "source": "笔芯信用",
            "content": "...",
            "view": null,
            "createTime": "2018-10-18 14:57:16",
            "updateTime": "2018-10-18 15:14:57",
            "tagIdArr": ["2"]
        },
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByUuid(ctx) {
  const {
    uuid
  } = ctx.request.data;

  if (!uuid) {
    ctx.body = ajaxResult.error('参数uuid不能为空', null, 12001);
  } else {
    const rsp = await newsService.findByUuid(uuid);
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};

/**
 * @api {post} /api/v1/news/updateViewById 根据id更新资讯点击数
 * @apiVersion 1.0.0
 * @apiName updateViewById
 * @apiGroup newsGroup
 * @apiParam {String} id

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/news/updateViewById', {id: 2});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数id不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": null,
        "msg": "更新成功",
        "code": 0
    }
 */

export async function updateViewById(ctx) {
  const {
    id
  } = ctx.request.data;

  if (!id) {
    ctx.body = ajaxResult.error('参数id不能为空', null, 12001);
  } else {
    const rsp = await newsService.updateViewById(id);
    ctx.body = ajaxResult.ok('更新成功', rsp);
  }
};
