import * as ajaxResult from '../util/ajaxResult';
import logService from '../service/logService';



/**
 * @apiDefine tracklogGroup 日志埋点操作
 */

/**
 * @api {post} /api/v1/track/add 新增埋点日志
 * @apiVersion 0.0.1
 * @apiName add
 * @apiGroup tracklogGroup

 * @apiParam {String} project 项目名称
 * @apiParam {String} category 埋点分类
 * @apiParam {String} action 埋点动作（日志信息）
 * @apiParam {String} property 埋点属性
 * @apiParam {String} value 埋点值（文本注释）
 * @apiParam {String} type 类型 1: 页面访问, 2: 点击动作, 3: 行为描述
 * @apiParam {String} userAgent userAgent
 * @apiParam {String} href 页面网址
 * @apiParam {String} pageName 页面路径
 * @apiParam {String} pagepath 页面路径不带参数
 * @apiParam {String} origin 页面域名
 * @apiParam {String} referer 页面referer
 * @apiParam {String} refererHost 页面referer的host
 * @apiParam {String} status 页面状态
 * @apiParam {String} method 请求方式
 * @apiParam {String} sourceChannel 来源，用于url上参数来额外区分用的，比如index.html?sourceChannel=baidu
 * @apiParam {String} ip ip
 * @apiParam {String} ip2 ip2 有些设备有2个ip地址
 * @apiParam {String} device 设备 android、ios、pc、other
 * @apiParam {String} deviceId 设备指纹
 * @apiParam {String} cookie 客户端cookie
 * @apiParam {Int} contentLength 返回的内容报文长度
 * @apiParam {String} userName 登录后的用户名

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/track/add', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": 1,
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function add (ctx) {
    const {project, category, action, property, value, type, userAgent, href, pageName, pagepath, origin, referer, refererHost, status, method, sourceChannel, ip, ip2, device, deviceId, cookie, contentLength, userName} = ctx.request.data;

    const rsp = await logService.insert({
        project,
        category,
        action,
        property,
        value,
        type,
        userAgent,
        href,
        origin,
        pageName,
        pagepath,
        referer,
        refererHost,
        status,
        method,
        sourceChannel,
        ip,
        ip2,
        device,
        deviceId,
        cookie,
        contentLength,
        userName
    });

    if(rsp){
        ctx.body = ajaxResult.ok('新增埋点日志成功', rsp)
    }else{
        ctx.body = ajaxResult.error('新增埋点日志失败', null)
    }
};

