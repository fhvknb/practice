import * as ajaxResult from '../util/ajaxResult';
import urlService from '../service/urlService';


/**
 * @apiDefine urlGroup 短链管理
 */

/**
 * @api {post} /api/v1/url/findByKey 根据key获取短链url
 * @apiVersion 1.0.0
 * @apiName findByKey
 * @apiGroup urlGroup
 * @apiParam {String} key 短链的key

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/url/findByKey', {key: ''});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数key不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": 'http://www.test.com/test.html',
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByKey (ctx) {
    const {key} = ctx.request.data;

    if(!key){
        ctx.body = ajaxResult.error('参数key不能为空', null, 12001);
    }else{
	    const rsp = await urlService.findByKey(key);
	    ctx.body = ajaxResult.ok('获取数据成功', rsp.url || '');
    }
};
