import * as ajaxResult from '../util/ajaxResult';
import * as CONST from '../util/const';
import util from '../util/util';
import {webHost} from '../config';
import configService from '../service/configService';
import newsService from '../service/newsService';



/**
 * @apiDefine configGroup 系统配置表
 */

/**
 * @api {post} /api/v1/config/findByKey 根据key获取配置数据
 * @apiVersion 1.0.0
 * @apiName findByKey
 * @apiGroup configGroup
 * @apiParam {String} key 键名

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/config/findByKey', {key: 'manage-recommend-list-config'});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数key不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": '1,2,3,4,5,6,7,8',
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByKey (ctx) {
  const {key} = ctx.request.data;

  if(!key){
    ctx.body = ajaxResult.error('参数key不能为空', null, 12001);
  }else{
    const rsp = await configService.findByKey(key);
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
  }
};

/**
 * @api {post} /api/v1/config/findByKeys 根据keys数组批量获取
 * @apiVersion 1.0.0
 * @apiName findByKeys
 * @apiGroup configGroup
 * @apiParam {Array} keys 键名

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/config/findByKeys', {
        keys: ['manage-news-detail-license-config', 'manage-recommend-list-config']
    });

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数key不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {
            "manage-recommend-list-config": "1,2,3,4,5,6,7,8",
            "manage-news-detail-license-config": "【原创及免责声明】凡注明 “麦芒管家原创”之作品，未经麦芒管家面授权，任何单位、和个人均不得转载、链接、转帖或者其他任何方式使用上述作品。否则，本站将依法追究责任。文章内容观点及结论仅供用户参考，不构成操作建议。商务合作联系请发邮件至： business_public@2dubao.com"
        },
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByKeys (ctx) {
    const {keys} = ctx.request.data;

    if(!keys){
        ctx.body = ajaxResult.error('参数keys不能为空', null, 12001);
    }else if(!Array.isArray(keys)){
        ctx.body = ajaxResult.error('参数keys必须为数组', null, 12002);
    }else{
        const rsp = await configService.findByKeys(keys);
        ctx.body = ajaxResult.ok('获取数据成功', rsp);
    }
};


/**
 * @api {post} /api/v1/config/findSitemapTxt 获取sitemap.txt
 * @apiVersion 1.0.0
 * @apiName findSitemapTxt
 * @apiGroup configGroup

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/config/findSitemapTxt', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数host不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": 'https://www.xbidai.com/gongju/',
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findSitemapTxt (ctx) {
  const key = CONST.ADMIN_SITEMAP_GONGJU_CONFIG;

  const configRsp = await configService.findByKey(key);
  const newsRsp = await newsService.findAllIds();
  const rsp = configRsp.split('\n').filter(item => !!item).join('\n') + '\n' + (newsRsp.map(({id}) => `${webHost}/gonglue/gonglue_${id}.html`).join('\n'));

  ctx.body = ajaxResult.ok('获取数据成功', rsp);
};


/**
 * @api {post} /api/v1/config/findSitemapXml 获取sitemap.xml
 * @apiVersion 1.0.0
 * @apiName findSitemapXml
 * @apiGroup configGroup

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/config/findSitemapXml', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 * @apiError 12001 参数host不能为空
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": '<?xmlversion="1.0"encoding="utf-8"?><urlset><url><loc>https://www.xbidai.com/gongju/</loc><priority>1.00</priority><changefreq>hourly</changefreq></url><urlset>',
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findSitemapXml (ctx) {
  const key = CONST.ADMIN_SITEMAP_GONGJU_CONFIG;

  const configRsp = await configService.findByKey(key);
  const newsRsp = await newsService.findAllIds();
  const configXml = configRsp.split('\n').filter(item => !!item).map((item) => {
    return `
    <url>
        <loc>${item}</loc>
        <priority>1.00</priority>
        <changefreq>hourly</changefreq>
    </url>`;
  }).join('');


  const newsXml = newsRsp.map(({id, lastmod}) => {
    return `
    <url>
        <loc>${webHost}/gonglue/gonglue_${id}.html</loc>
        <priority>1.00</priority>
        <changefreq>daily</changefreq>
        <lastmod>${lastmod}</lastmod>
    </url>`;
  }).join('');

  const rsp =`<?xml version="1.0" encoding="utf-8"?>
<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>${configXml}${newsXml}
</urlset>`;
  ctx.body = ajaxResult.ok('获取数据成功', rsp);
};

/**
 * @api {post} /api/v1/config/findAppshopIndex h5额度宝定制-应用超市定制接口-获取首页数据
 * @apiVersion 1.0.0
 * @apiName findByKey
 * @apiGroup configGroup
 * @apiParam {String} key 键名

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/config/findAppshopIndex', {});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": {},
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findAppshopIndex (ctx) {
  const key = 'edb-appshop-page-index';

  const rsp = await configService.findByKey(key);
  const data = util.jsonParse(rsp);
  for(let i in data){
    data[i] = (data[i] || []).filter(item => item.status === 0)
  }

  ctx.body = ajaxResult.ok('获取数据成功', JSON.stringify(data));
};
