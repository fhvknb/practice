import * as ajaxResult from '../util/ajaxResult';
import mobileService from '../service/mobileService';


/**
 * @apiDefine mobileGroup 手机号码管理
 */

/**
 * @api {post} /api/v1/mobile/save 保存手机号码
 * @apiVersion 1.0.0
 * @apiName save
 * @apiGroup mobileGroup
 * @apiParam {String} mobile 手机号码

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/tag/findByIds', {ids: [2]});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
      "data": null,
      "msg": "获取数据成功",
      "code": 0
    }
 */

export async function save (ctx) {
  const {mobile} = ctx.request.data;
  if (!mobile) {
    ctx.body = ajaxResult.error('参数mobile不能为空', null, 12001);
  }
  const rsp = await mobileService.save({mobile});
  ctx.body = ajaxResult.ok('保存成功', rsp);
};
