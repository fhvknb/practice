import * as ajaxResult from '../util/ajaxResult';
import classifyService from '../service/classifyService';


/**
 * @apiDefine classifyGroup 分类管理
 */

/**
 * @api {post} /api/v1/classify/findByIds 根据ids批量获取分类
 * @apiVersion 1.0.0
 * @apiName findByIds
 * @apiGroup classifyGroup
 * @apiParam {Array} ids 数组或者null，若为null默认查询所有

 * @apiParamExample {json} 请求参数实例:
    const rsp = await api.post('/classify/findByIds', {ids: null});

 * @apiSuccess {String} code=0 成功
 * @apiSuccess {String} msg 结果提示语
 * @apiSuccess {Object} data 返回数据
 *
 * @apiError 10001 签名验证失败
 *
 * @apiSuccessExample 请求成功返回值
    {
        "data": [
            {
                "id": 9,
                "name": "房产",
                "createTime": "2018-10-22 13:44:34"
            },
            {
                "id": 6,
                "name": "攻略",
                "createTime": "2018-10-17 15:51:06"
            },
            {
                "id": 5,
                "name": "信用卡",
                "createTime": "2018-10-17 15:50:58"
            },
            {
                "id": 4,
                "name": "贷款",
                "createTime": "2018-10-17 15:50:54"
            }
        ],
        "msg": "获取数据成功",
        "code": 0
    }
 */

export async function findByIds (ctx) {
    const {ids} = ctx.request.data;

    const rsp = await classifyService.findByIds(ids);
    ctx.body = ajaxResult.ok('获取数据成功', rsp);
};
