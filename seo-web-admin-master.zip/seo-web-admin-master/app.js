const appStartTime = Date.now();
const Koa = require('koa');
const app = new Koa();
const views = require('koa-views');
const cors = require('koa2-cors');
const qs = require('qs');
const json = require('koa-json');
const body = require('koa-better-body');
const onerror = require('koa-onerror');
const convert = require('koa-convert');
const routes = require("./routes");
const util = require("./util/util.js");
const api = require("./util/api.js");
const middlewares = require('./middlewares');
const trackService = require('./service/trackService');
require('./service/runJobService');
const {env, port, ip} = require('./config');

const VIEWS_DIR = '/views';		//html文件目录位置
const STATIC_DIR = '/public';	//静态资源文件目录位置

app.use(json());

app.use(convert(body({
	fields:'body',
	formLimit: '50mb',
	textLimit: '50mb',
	urlencodedLimit: '50mb',
	bufferLimit: '50mb',
	jsonLimit: '50mb',
  	querystring: qs
})));

// app.use(cors({
//     origin: function(ctx) {
//       return '*';
//     },
//     exposeHeaders: ['Login-Token', 'Login-expires'],
//     maxAge: 5,  //预检请求的有效期，单位为秒，好像无效果。。
//     credentials: true,
//     allowMethods: ['GET', 'POST', 'OPTIONS'],
//     allowHeaders: ['Content-Type', 'Authorization', 'Accept', 'token'],
// }));

app.use(require('koa-static')(__dirname + STATIC_DIR), {
	maxage: 24 * 60 * 60 * 1000
});

app.use(views(__dirname + VIEWS_DIR, {
  	extension: 'ejs'
}));

onerror(app);

//中间件管理
middlewares(app);

//错误日志
app.on('error', function(err = {}, ctx){
    const ip = util.getIp(ctx);
    const msg = err.stack || err.message || err;
    const content = `[${ip}]system found error! url:${ctx.request.url}, error msg: ${msg}`;
    global.logger.error(content);

    trackService.trackSystemLog(ctx, {
      action: 'error',
      property: msg
    })
});

//启动日志
global.logger.log(`项目启动成功!, 当前环境: ${env}, 当前url: http://${ip}:${port}`);
trackService.trackSystemLog(null, {
  action: 'log',
  property: '项目启动成功',
  value: Date.now() - appStartTime
})

//配置路由
routes(app);

module.exports = app;
